var colors = ["purple","blue","red","orange", "green", "white"];

function Snoepje(x,y,w){

    this.x=x;
    this.y=y;
    this.w=w;
    this.colors =random(colors);

}


Snoepje.prototype.show= function(){
    noLoop();
    stroke(0);
    // let c = random(colors);
    fill(this.colors);
    rect(this.x,this.y,this.w,this.w);
}