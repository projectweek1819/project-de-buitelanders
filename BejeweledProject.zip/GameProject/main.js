var cols ;
var rows ;
var colors = ["purple","blue","red","orange", "green", "white"];
//var img = document.createElement("img");
var field;

var w =50;



function make2DArray(cols, rows){
    var arr= new Array(cols);
    for(var  i = 0 ; i < arr.length ; i++){
        arr[i]=new Array(rows);
    }
    return arr;
}



function setup() {
    createCanvas(501,501);

    cols= floor(width / w);
    rows=floor(height / w);
    field= make2DArray(cols,rows);

    for(var i = 0 ; i < cols; i++){
        for(var j = 0 ; j < rows ; j++){
            field[i][j]= new Snoepje(i*w,j*w,w,w);
            let position = {i,j};

            console.log(field[i][j]);
            console.log(horizontalChainAt(field,position));
        }
    }


    for(var i = 0 ; i < cols; i++){
        for(var j = 0 ; j < rows ; j++){

            let position = {i,j};



            while(horizontalChainAt(field,position) >= 3 || verticalChainAt(field,position) >= 3) {

                field[i][j]= new Snoepje(i*w,j*w,w,w);
                console.log(horizontalChainAt(field,position) + "hola puto");
            }
        }
    }


}

function draw() {
    background(255);
    for(let i = 0 ; i < cols; i++){
        for(let j = 0 ; j < rows ; j++){
            field[i][j].show();

        }
    }
}


function fieldWidth(field){
    field= make2DArray(cols,rows);
    return field[0].length;
}

function fieldHeight(field){
    field= make2DArray(cols,rows);
    return field.length;
}

function horizontalChainAt(field, position){


    let { x,y } = position;
    let counter=0;
    while ( x > 0 && field[x-1][y] == field[x][y]) x--;
    while ( x < fieldWidth(field)-1 && field[x][y] == field[x+1][y]) {
        counter++;
        ++x;
    }
    return counter+1;
}

function verticalChainAt(field, position){

    let { x,y } = position;

    let counter=0;

    while( y > 0 && field[y-1][x]=== field[y][x]) y--;
    while( y< fieldHeight(field)-1 && field[y][x] === field[y+1][x]){
        counter++
        ++y
    }
    return counter+1;
}

/*

function swap(field,q,p){

    let temp= field[q.y][q.x];

    field[q.y][q.x]= field[p.y][p.x];
    field[p.y][p.x]=temp;

}
*/




































/*
var cols =8;
var rows = 8;
var field = [];
var colors = [""];
var img = document.createElement("img");




function setup() {
    createCanvas(500, 500);
    for (var i = 0; i < cols; i++) {
        field[i] = [];
        for (var j = 0; j < rows; j++) {
            field[i][j] = random(colors);
        }
    }
    img4 = loadImage("imgs/3.gif");
    img = loadImage("imgs/blauw.gif");
    img2 = loadImage("imgs/geel.gif");
    img3 = loadImage("imgs/2.gif");
    img5 = loadImage("imgs/paars.gif");
    img6 = loadImage("imgs/6.gif");


}

function draw() {
    background("lightblue");

    for (var i = 0; i < cols; i++) {
        for (var j = 0; j < rows; j++) {
            var x= i *72;
            var y = j * 72;

            fill(field[i][j]);
            stroke(0);

            image(img4,x, y );
            image(img2, x, y);
            image(img, x, y);
            image(img4, x, y);
            image(img5, x, y);
            image(img6, x, y);


        }
    }



}
*/
